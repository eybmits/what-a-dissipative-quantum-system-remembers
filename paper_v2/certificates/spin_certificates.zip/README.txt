Spin certificate capsule for "The form of dissipation shapes what a quantum reservoir remembers"

This small package verifies the collective-loss spin instances, certified coupling
neighborhoods, the continuous matched-drive coefficient interval, and the
finite-rate coherence intervention. It also includes the numerical
full-map check of the separate analytic three-level model. Its two numerical methods use Arb
intervals and independently extrapolated full density-matrix maps. It needs no
other data. From this directory on macOS/Linux:

  python3.13 -m venv .cert
  .cert/bin/python -m pip install -r certificate-requirements.txt
  .cert/bin/python verify_certificates.py --receipt verified.json

To run the independent integer Pauli-algebra and exact Sturm-spectrum check
directly, use .cert/bin/python evidence/review_audit/exact_inputs.py. For the
independent numerical three-level check, see evidence/generality_extension/README.txt.

Reference replay used CPython 3.13.2. A normal run with assertions enabled must
print the four passing instances and the matched coefficient checks. This is
a local computational verification. The derivation and its hypotheses are
written out in three_spin_limits.pdf next to this archive, and Appendix D of
the paper summarises them. The code and data behind its figures are at
https://github.com/eybmits/what-a-dissipative-quantum-system-remembers
