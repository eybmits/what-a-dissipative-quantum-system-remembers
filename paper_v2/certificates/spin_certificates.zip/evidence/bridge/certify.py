"""Arb interval certificates for the four specified physical fixed-gain limits.

Requires python-flint>=0.9 (ball matrices). Pauli actions below are assembled
from Gaussian integers / powers of two, exactly representable in binary64.
All operations involving couplings, roots, inverses and exponentials then use
192-bit real/complex balls. The floating couplings are interpreted as the exact
dyadic values produced by the declared NumPy generator.
"""

from pathlib import Path
import itertools
import json
import numpy as np
import flint
from flint import arb, arb_mat as M, acb, acb_mat as C

HERE = Path(__file__).resolve().parent
flint.ctx.prec = 192


def exact(a):
    num, den = float(a).as_integer_ratio()
    return arb(num) / den


def eye(n):
    return M([[int(i == j) for j in range(n)] for i in range(n)])


def block(a, rows, cols):
    return M([[a[i, j] for j in cols] for i in rows])


def frob(a):
    return sum(v * v for v in a.entries()).sqrt()


def dyadic_pauli_coefficients(images, paulis):
    trace = np.einsum("aij,bji->ab", paulis, images) / 8
    assert np.max(abs(trace.imag)) == 0
    # Gaussian-integer sums: the anticommutator contributes a factor of 1/2.
    assert np.all(trace.real * 16 == np.rint(trace.real * 16))
    return M([[exact(x) for x in row] for row in trace.real])


def geometry():
    local = [
        np.eye(2),
        np.array([[0, 1], [1, 0]]),
        np.array([[0, -1j], [1j, 0]]),
        np.diag([1, -1]),
    ]

    def tensor(l):
        return np.kron(np.kron(l[0], l[1]), l[2])

    paulis = np.array(
        [
            tensor([local[i] for i in lab])
            for lab in itertools.product(range(4), repeat=3)
        ]
    )
    lowering = np.array([[0, 1], [0, 0]])
    jump = sum(
        c * tensor([lowering if i == j else local[0] for i in range(3)])
        for j, c in enumerate((1, -1, -1))
    )
    k = jump.T @ jump
    D = dyadic_pauli_coefficients(
        jump @ paulis @ jump.T - (k @ paulis + paulis @ k) / 2, paulis
    )
    x = [tensor([local[1] if i == j else local[0] for i in range(3)]) for j in range(3)]
    z = [tensor([local[3] if i == j else local[0] for i in range(3)]) for j in range(3)]
    g = lambda h: dyadic_pauli_coefficients(-1j * (h @ paulis - paulis @ h), paulis)
    hstatic = g(sum(z) / 2 + 3 * sum(x) / 4)
    drive = g(sum(x) / 4)
    xx = [g(x[i] @ x[j]) for i, j in itertools.combinations(range(3), 2)]
    cc = arb(2).sqrt()
    q = arb(6).sqrt()
    w = C(8, 3)
    w[0, 0] = 1
    for i, v in zip([4, 2, 1], [0, 1, -1]):
        w[i, 1] = v / cc
    for i, v in zip([4, 2, 1], [2, 1, 1]):
        w[i, 2] = v / q
    bases = [C([[int(i == j) / arb(3).sqrt() for j in range(3)] for i in range(3)])]
    for i in range(3):
        for j in range(i + 1, 3):
            a = C(3, 3)
            a[i, j] = 1 / cc
            a[j, i] = 1 / cc
            bases.append(a)
            a = C(3, 3)
            a[i, j] = acb(0, -1 / cc)
            a[j, i] = acb(0, 1 / cc)
            bases.append(a)
    for vals, den in [([1, -1, 0], cc), ([1, 1, -2], q)]:
        a = C(3, 3)
        for i, v in enumerate(vals):
            a[i, i] = v / den
        bases.append(a)
    embedded = [w * b * w.transpose() for b in bases]
    R = M(64, 9)
    for i, p in enumerate(paulis):
        pp = C([[acb(int(z.real), int(z.imag)) for z in row] for row in p])
        for j, b in enumerate(embedded):
            R[i, j] = (pp * b).trace().real / arb(8).sqrt()
    LT = R.transpose() * (D + R * R.transpose()).inv()
    P = R * LT
    S = (D + P).inv() - P
    return D, R, LT, S, hstatic, drive, xx


def interval(x):
    assert x.is_finite()
    return x.str(22)


def certify(seed, geom):
    D, R, LT, S, Hbase, drive, xx = geom
    # The coefficients below are dyadic, not intervals centered at a printed decimal.
    rng = np.random.default_rng(seed)
    js = [float(rng.uniform(-1, 1)) for _ in range(3)]
    Hbase = Hbase + sum((exact(j) * h for j, h in zip(js, xx)), M(64, 64))
    B = block(R, range(1, 64), range(1, 9))
    left = block(LT, range(1, 9), range(1, 64))
    rho = block(R, range(64), [0]) / arb(3).sqrt()
    Ms = []
    Ds = []
    bs = []
    Os = []
    for sign in [-1, 1]:
        H = Hbase + sign * drive
        G = LT * H * R / 2
        G1 = -LT * H * S * H * R / 2
        aug = M(18, 18)
        for i in range(9):
            for j in range(9):
                aug[i, j] = G[i, j]
                aug[9 + i, 9 + j] = G[i, j]
                aug[i, 9 + j] = G1[i, j]
        exp = aug.exp()
        E = block(exp, range(9), range(9))
        E1 = block(exp, range(9), range(9, 18))
        zero = R * E * LT
        one = -S * H * R * E * LT - R * E * LT * H * S + R * E1 * LT
        Ms.append(block(zero, range(1, 64), range(1, 64)))
        Ds.append(block(one, range(1, 64), range(1, 64)))
        bs.append(block(one * rho, range(1, 64), [0]))
        Os.append(block(E, range(1, 9), range(1, 9)))
    O = sum(Os, M(8, 8)) / 2
    radius_power_bound = frob(O**4096)
    assert radius_power_bound < 1
    coords = [(i, j) for i in range(8) for j in range(i + 1)]
    dim = len(coords)
    idvec = M([[int(i == j) / arb(8).sqrt()] for i, j in coords])
    T = M(dim, dim)
    sqrt2 = arb(2).sqrt()
    for col, (i, j) in enumerate(coords):
        v = M(8, 8)
        v[i, j] = 1 if i == j else 1 / sqrt2
        v[j, i] = v[i, j]
        tv = sum((o * v * o.transpose() for o in Os), M(8, 8)) / 2
        for row, (a, b) in enumerate(coords):
            T[row, col] = tv[a, b] * (1 if a == b else sqrt2)
    bordered = eye(dim) - T + idvec * idvec.transpose()
    inverse = bordered.inv()
    singular_lower = 1 / frob(inverse)
    assert singular_lower > arb("1e-5")
    d0 = 1 - sum(x * x for x in O.entries()) / 8
    ell = lambda X: (left * X * left.transpose()).trace() / 8
    mean = (eye(63) - (Ms[0] + Ms[1]) / 2).solve((bs[0] + bs[1]) / 2)
    z = [a * mean + b - mean for a, b in zip(Ms, bs)]
    V = sum((a * a.transpose() for a in z), M(63, 63)) / 2
    write = ell(V)
    R0 = B * B.transpose()
    kappa = -ell(
        sum(
            (
                a1 * R0 * a0.transpose() + a0 * R0 * a1.transpose()
                for a0, a1 in zip(Ms, Ds)
            ),
            M(63, 63),
        )
        / 2
    )
    beta = kappa / d0
    assert write > arb(".3") and kappa > 3 and d0 > arb(".05") and beta > 60
    # X on first qubit = Pauli index 16, hence index 15 after deleting trace.
    visible = R0[15, 15]
    assert visible.contains(arb(1) / 6)
    return dict(
        seed=seed,
        couplings_as_integer_ratios=[list(v.as_integer_ratio()) for v in js],
        first_moment_4096_power_frobenius=interval(radius_power_bound),
        bordered_twirl_singular_lower=interval(singular_lower),
        writing=interval(write),
        kappa=interval(kappa),
        d0=interval(d0),
        beta=interval(beta),
        X1_visibility=interval(visible),
    )


if __name__ == "__main__":
    geom = geometry()
    results = [certify(seed, geom) for seed in [8675309, 424242, 97531, 123457]]
    out = dict(
        python_flint=flint.__version__, precision_bits=flint.ctx.prec, records=results
    )
    print(json.dumps(out, indent=2))
    (HERE / "certificates.json").write_text(json.dumps(out, indent=2) + "\n")
