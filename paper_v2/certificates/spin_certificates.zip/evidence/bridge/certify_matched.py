"""Rigorous-ball secular certificate for matched gain in the three-spin model."""

from pathlib import Path
import json
import itertools
import numpy as np
import flint
from flint import arb, arb_mat as M, acb, acb_mat as C
from certify import eye, block, geometry, exact, interval

HERE = Path(__file__).resolve().parent


def cmatrix(m):
    return C([[acb(m[i, j]) for j in range(m.ncols())] for i in range(m.nrows())])


def hamiltonian(seed):
    local = [np.eye(2), np.array([[0, 1], [1, 0]]), np.diag([1, -1])]
    tn = lambda ops: np.kron(np.kron(ops[0], ops[1]), ops[2])
    xs = [tn([local[1] if i == j else local[0] for i in range(3)]) for j in range(3)]
    zs = [tn([local[2] if i == j else local[0] for i in range(3)]) for j in range(3)]
    to_m = lambda x: M([[exact(v) for v in row] for row in x])
    js = np.random.default_rng(seed).uniform(-1, 1, 3)
    h = to_m(sum(zs) / 2 + 0.75 * sum(xs))
    for val, (i, j) in zip(js, itertools.combinations(range(3), 2)):
        h = h + exact(val) * to_m(xs[i] @ xs[j])
    W = M(8, 3)
    W[0, 0] = 1
    for i, v in zip((4, 2, 1), (0, 1, -1)):
        W[i, 1] = v / arb(2).sqrt()
    for i, v in zip((4, 2, 1), (2, 1, 1)):
        W[i, 2] = v / arb(6).sqrt()
    return W.transpose() * h * W, W.transpose() * to_m(xs[0]) * W


def qutrit_basis():
    q = arb(2).sqrt()
    I = eye(3)
    result = [cmatrix(I) / arb(3).sqrt()]
    for i in range(3):
        for j in range(i + 1, 3):
            x = C(3, 3)
            x[i, j] = 1 / q
            x[j, i] = 1 / q
            result.append(x)
            x = C(3, 3)
            x[i, j] = acb(0, -1 / q)
            x[j, i] = acb(0, 1 / q)
            result.append(x)
    for vals, den in [([1, -1, 0], q), ([1, 1, -2], arb(6).sqrt())]:
        x = C(3, 3)
        for i, v in enumerate(vals):
            x[i, i] = v / den
        result.append(x)
    return result


def gram(a, b):
    return (a.transpose() * b).trace()


def stable(matrix):
    n = matrix.nrows()
    poly = matrix.charpoly()
    coef = [poly[n - j] for j in range(n + 1)]
    hur = M(
        [
            [
                coef[2 * j - i + 1] if 0 <= 2 * j - i + 1 <= n else arb(0)
                for j in range(n)
            ]
            for i in range(n)
        ]
    )
    determinants = [block(hur, range(k), range(k)).det() for k in range(1, n + 1)]
    assert all(val > 0 for val in determinants)
    return [interval(val) for val in determinants]


def make_certificate(seed, geom, horizon_est):
    D, R, LT, S, Hbase, drive, xx = geom
    half = arb(1) / 2
    g = 8
    js = np.random.default_rng(seed).uniform(-1, 1, 3)
    H = Hbase + sum((exact(v) * h for v, h in zip(js, xx)), M(64, 64))
    Hd, Xd = hamiltonian(seed)
    energy = sorted((z.real for z in Hd.eig()), key=lambda x: float(x.mid()))
    assert all(energy[i] < energy[i + 1] for i in range(2))
    projs = []
    for i, e in enumerate(energy):
        P = eye(3)
        for j, other in enumerate(energy):
            if i != j:
                P = P * (Hd - other * eye(3)) / (e - other)
        projs.append(cmatrix(P))
    phases = [acb(1)] + [
        acb(0, half * (u - v)).exp()
        for i, u in enumerate(energy)
        for j, v in enumerate(energy)
        if i != j
    ]
    sep = min(abs(a - b).lower() for a, b in itertools.combinations(phases, 2))
    assert sep > arb(".3")
    tb = qutrit_basis()
    proj = M([[(t * p).trace().real for p in projs] for t in tb])
    sqrt2 = arb(2).sqrt()
    va = (block(proj, range(1, 9), [0]) - block(proj, range(1, 9), [1])) / sqrt2
    vb = (
        block(proj, range(1, 9), [0])
        + block(proj, range(1, 9), [1])
        - 2 * block(proj, range(1, 9), [2])
    ) / arb(6).sqrt()
    basis = [
        va * va.transpose(),
        vb * vb.transpose(),
        (va * vb.transpose() + vb * va.transpose()) / sqrt2,
    ]
    for i, j in itertools.combinations(range(3), 2):
        pi, pj = projs[i], projs[j]
        plane = M(
            [
                [(ta * (pi * tb0 * pj + pj * tb0 * pi)).trace().real for tb0 in tb[1:]]
                for ta in tb[1:]
            ]
        )
        basis.append(plane / sqrt2)
    G = half * LT * H * R
    Gd = (half * g) * LT * drive * R
    Gl = -half * LT * H * S * H * R
    aug = M(27, 27)
    for i in range(9):
        for j in range(9):
            for k in range(3):
                aug[9 * k + i, 9 * k + j] = G[i, j]
            aug[i, 9 + j] = Gd[i, j]
            aug[9 + i, 18 + j] = Gd[i, j]
            aug[i, 18 + j] = Gl[i, j]
    exp = aug.exp()
    E = block(exp, range(9), range(9))
    D1 = block(exp, range(9), range(9, 18))
    E1 = block(exp, range(9), range(18, 27))
    rates = proj.transpose() * E1 * proj
    off = min([rates[i, j].lower() for i in range(3) for j in range(3) if i != j])
    assert off > 0
    peq = M([[rates[i, j] if i < 2 else arb(1) for j in range(3)] for i in range(3)])
    pop = peq.solve(M([[0], [0], [1]]))
    assert all(p > 0 for p in pop.entries())
    m = proj * pop
    v = block(D1 * m, range(1, 9), [0])
    O = block(E, range(1, 9), range(1, 9))
    d = block(D1, range(1, 9), range(1, 9))
    e = block(E1, range(1, 9), range(1, 9))
    Kb = M(
        [
            [gram(x, e * y * O.transpose() + O * y * e.transpose()) for y in basis]
            for x in basis
        ]
    )
    Kt = Kb + M([[gram(x, d * y * d.transpose()) for y in basis] for x in basis])
    detB = stable(Kb)
    detT = stable(Kt)
    write = M([[gram(x, v * v.transpose())] for x in basis])
    wc = (-Kb).solve(write)
    sc = (-Kt).solve(write)
    xf = M([[(t * cmatrix(Xd)).trace().real] for t in tb])
    a = block(xf, range(1, 9), [0])
    aw = M([[gram(x, a * a.transpose()) for x in basis]])
    ym = (xf.transpose() * m)[0, 0]
    variance = (aw * sc)[0, 0]
    signal = (aw * wc)[0, 0]
    den = variance + (1 - ym * ym - variance) / 1000
    Rlim = signal / den
    assert signal > 0 and variance > 0 and den > 0 and Rlim > 0
    lo = round(horizon_est, 6) - 2e-6
    hi = round(horizon_est, 6) + 2e-6
    tail = lambda h: (aw * (exact(h) * Kb).exp() * wc)[0, 0] / signal
    left = tail(lo)
    right = tail(hi)
    assert left > arb(".1") and right < arb(".1")
    return dict(
        seed=seed,
        min_phase_separation=interval(sep),
        min_population_offdiag=interval(off),
        hurwitz_determinants_mean_gramian=detB,
        hurwitz_determinants_covariance=detT,
        X1_limiting_past_recall=interval(Rlim),
        X1_limiting_variance=interval(variance),
        X1_positive_linear_gramian=interval(signal),
        scaled_horizon_bracket=[lo, hi],
        scaled_horizon_tail_bounds=[interval(left), interval(right)],
    )


if __name__ == "__main__":
    geom = geometry()
    est = {
        r["seed"]: r["x1_scaled_horizon_limit"]
        for r in json.loads((HERE / "matched_limit.json").read_text())
    }
    results = [
        make_certificate(seed, geom, est[seed])
        for seed in [8675309, 424242, 97531, 123457]
    ]
    report = dict(
        precision_bits=flint.ctx.prec, python_flint=flint.__version__, results=results
    )
    (HERE / "matched_certificates.json").write_text(json.dumps(report, indent=2) + "\n")
    for r in results:
        print(r["seed"], r["X1_limiting_past_recall"], r["scaled_horizon_bracket"])
