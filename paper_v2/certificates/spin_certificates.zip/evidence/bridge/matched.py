"""Matched-drive secular-limit calculation in the dark qutrit of three spins."""

from pathlib import Path
import json
from spin_bridge import (
    SpinModel,
    geometry,
    dark_isometry,
    hermitian_qutrit_basis,
    SEEDS,
    la,
    np,
    HERE,
)


def matched(seed, gain_scale=8):
    model = SpinModel(3, seed)
    W = dark_isometry()
    Tb = hermitian_qutrit_basis()
    R, L, S = geometry(model)
    H0 = model.static
    J = model.couplings
    x = [model.operator(1, [i]) for i in range(3)]
    z = [model.operator(3, [i]) for i in range(3)]
    H = (
        sum(z) / 2
        + 3 * sum(x) / 4
        + J[0] * x[0] @ x[1]
        + J[1] * x[0] @ x[2]
        + J[2] * x[1] @ x[2]
    )
    energies, U = la.eigh(W.T @ H @ W)
    enph = np.exp(-0.5j * energies)
    phases = [
        enph[i] * enph[j].conjugate() for i in range(3) for j in range(3) if i != j
    ] + [1.0 + 0j]
    sep = min(abs(x - y) for i, x in enumerate(phases) for y in phases[i + 1 :])
    assert sep > 1e-8
    dv = lambda op: np.einsum("aij,ji->a", Tb, op).real
    diag = np.stack([dv(np.outer(e, e)) for e in U.T], axis=1)
    va = (diag[:, 0] - diag[:, 1])[1:] / np.sqrt(2)
    vb = (diag[:, 0] + diag[:, 1] - 2 * diag[:, 2])[1:] / np.sqrt(6)
    basis = [
        np.outer(va, va),
        np.outer(vb, vb),
        (np.outer(va, vb) + np.outer(vb, va)) / np.sqrt(2),
    ]
    for i in range(3):
        for j in range(i + 1, 3):
            f = np.outer(U[:, i], U[:, j])
            a = dv((f + f.T) / np.sqrt(2))[1:]
            b = dv(1j * (f - f.T) / np.sqrt(2))[1:]
            basis.append((np.outer(a, a) + np.outer(b, b)) / np.sqrt(2))
    X = np.array(basis)
    assert la.norm(X.reshape(6, 64) @ X.reshape(6, 64).T - np.eye(6)) < 1e-12
    G = 0.5 * L.T @ H0 @ R
    Gd = 0.5 * gain_scale * L.T @ model.drive @ R
    Gl = -0.5 * L.T @ H0 @ S @ H0 @ R
    aug = np.zeros((27, 27))
    for i in range(3):
        aug[i * 9 : i * 9 + 9, i * 9 : i * 9 + 9] = G
    aug[:9, 9:18] = Gd
    aug[9:18, 18:] = Gd
    aug[:9, 18:] = Gl
    exp = la.expm(aug)
    E = exp[:9, :9]
    D1 = exp[:9, 9:18]
    E1 = exp[:9, 18:]
    rates = diag.T @ E1 @ diag
    probs = la.solve(np.vstack((rates[:2], np.ones(3))), [0, 0, 1])
    assert np.max(abs(rates @ probs)) < 1e-10
    m = diag @ probs
    v = (D1 @ m)[1:]
    O = E[1:, 1:]
    D = D1[1:, 1:]
    e = E1[1:, 1:]
    assert la.norm(O @ X @ O.T - X) < 1e-10
    write = np.einsum("aij,i,j->a", X, v, v)
    Kb = np.einsum("aij,bij->ab", X, e @ X @ O.T + O @ X @ e.T)
    Kt = Kb + np.einsum("aij,bij->ab", X, D @ X @ D.T)
    w = la.solve(-Kb, write)
    sigma = la.solve(-Kt, write)
    a = dv(W.T @ x[0] @ W)
    aw = np.einsum("i,aij,j->a", a[1:], X, a[1:])
    ym = a @ m
    variance = aw @ sigma
    den = variance + (1 - ym**2 - variance) / 1000
    sig = aw @ w
    recall = sig / den
    horizon = __import__("scipy").optimize.brentq(
        lambda t: aw @ la.expm(t * Kb) @ w / sig - 0.1, 0, 50
    )
    return dict(
        seed=seed,
        phase_separation=sep,
        rates=rates.tolist(),
        distribution=probs.tolist(),
        kb_max_eigen_real=max(la.eigvals(Kb).real),
        kt_max_eigen_real=max(la.eigvals(Kt).real),
        x1_population_recall_limit=recall,
        x1_variance=variance,
        x1_past_gram=sig,
        x1_mean=ym,
        x1_scaled_horizon_limit=horizon,
        Kb=Kb.tolist(),
        Kt=Kt.tolist(),
        v=v.tolist(),
    )


if __name__ == "__main__":
    rows = [matched(s) for s in SEEDS]
    (HERE / "matched_limit.json").write_text(json.dumps(rows, indent=2) + "\n")
    for x in rows:
        print(
            x["seed"],
            x["phase_separation"],
            x["kb_max_eigen_real"],
            x["kt_max_eigen_real"],
            x["x1_population_recall_limit"],
            x["x1_scaled_horizon_limit"],
        )
