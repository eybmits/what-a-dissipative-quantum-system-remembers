"""Independent finite-rate extrapolation for the two three-spin propositions.

Builds column-vectorized GKSL matrices and SVD dark spaces directly. Nothing
from the certificate or the original moment solvers is imported. This is a
floating-point check, not a source of interval bounds.
"""

import itertools
import numpy as np
from scipy import linalg as la
from scipy.optimize import brentq

I2 = np.eye(2)
LOWER = np.array([[0.0, 1.0], [0.0, 0.0]])
PAULI_X = LOWER + LOWER.T
PAULI_Z = np.diag([1.0, -1.0])


def embed_site(op, site):
    sites = [I2] * 3
    sites[site] = op
    return np.kron(np.kron(sites[0], sites[1]), sites[2])


def hermitian_basis(d):
    """Coordinate zero is the normalized identity. All matrices have unit HS norm."""
    basis = [np.eye(d) / np.sqrt(d)]
    for j in range(1, d):
        v = np.zeros(d)
        v[:j], v[j] = 1, -j
        basis.append(np.diag(v) / np.sqrt(j * (j + 1)))
    for i, j in itertools.combinations(range(d), 2):
        e = np.zeros((d, d), complex)
        e[i, j] = 1 / np.sqrt(2)
        basis.extend((e + e.T, 1j * (e - e.T)))
    return np.array(basis)


def frame(operators):
    return np.column_stack([x.reshape(-1, order="F") for x in operators])


def as_real(matrix):
    if np.max(abs(matrix.imag)) > 2e-10:
        raise ValueError("Hermitian representation is not real")
    return matrix.real


def commutator(h):
    identity = np.eye(len(h))
    return -1j * (np.kron(identity, h) - np.kron(h.T, identity))


def sym_basis(d):
    basis = []
    for i in range(d):
        for j in range(i + 1):
            e = np.zeros((d, d))
            e[i, j] = 1 if i == j else 1 / np.sqrt(2)
            e[j, i] = e[i, j]
            basis.append(e)
    return np.array(basis)


class FullModel:
    def __init__(self, couplings):
        xs = [embed_site(PAULI_X, k) for k in range(3)]
        zs = [embed_site(PAULI_Z, k) for k in range(3)]
        jump = sum(c * embed_site(LOWER, k) for k, c in enumerate((1, -1, -1)))
        h = sum(zs) / 2 + 3 * sum(xs) / 4
        for coupling, (i, j) in zip(couplings, itertools.combinations(range(3), 2)):
            h += coupling * (xs[i] @ xs[j])
        drive_h = sum(xs) / 4
        normop = jump.conj().T @ jump
        eye = np.eye(8)
        diss = (
            np.kron(jump.conj(), jump)
            - (np.kron(eye, normop) + np.kron(normop.T, eye)) / 2
        )
        basis = frame(hermitian_basis(8))
        self.diss = as_real(basis.conj().T @ diss @ basis)
        self.static = as_real(basis.conj().T @ commutator(h) @ basis)
        self.drive = as_real(basis.conj().T @ commutator(drive_h) @ basis)
        # SVD constructs the stationary Hilbert subspace and the left eigenvectors
        # independently of any supplied dark-basis vectors or Drazin expressions.
        w = la.null_space(jump)
        assert w.shape == (8, 3)
        q = frame(hermitian_basis(3))
        self.q = q
        self.R = as_real(basis.conj().T @ np.kron(w.conj(), w) @ q)
        dual = la.null_space(self.diss.T).T
        assert dual.shape == (9, 64)
        self.left = la.solve(dual @ self.R, dual)
        self.hdark = w.conj().T @ h @ w
        self.udark = w.conj().T @ drive_h @ w
        self.xdark = w.conj().T @ xs[0] @ w
        assert la.norm(self.left @ self.R - np.eye(9)) < 1e-11
        assert la.norm(self.left @ self.diss) < 1e-11

    def full_step(self, eps, gain):
        return la.expm(0.5 * (self.diss / eps + self.static + gain * self.drive))

    def unitary_step(self, gain):
        u = la.expm(-0.5j * (self.hdark + gain * self.udark))
        return as_real(self.q.conj().T @ np.kron(u.conj(), u) @ self.q)


def extrapolate(samples, eps):
    """Polynomial extrapolation at zero from equally ratio-spaced arguments."""
    weights = [np.prod([-b / (a - b) for b in eps if b != a]) for a in eps]
    return np.tensordot(weights, samples, axes=(0, 0))


def fixed_result(model, eps):
    inn = model.R[:, 0] / np.sqrt(3)
    finite = []
    limits = []
    rotations = []
    for sign in (-1, 1):
        rotation = model.unitary_step(sign)
        zeroth = model.R @ rotation @ model.left
        limits.append(zeroth[1:, 1:])
        rotations.append(rotation[1:, 1:])
        derivatives = [(model.full_step(e, sign) - zeroth) / e for e in eps]
        finite.append(extrapolate(derivatives, eps))
    injection = [(d @ inn)[1:] for d in finite]
    mean = la.solve(np.eye(63) - np.mean(limits, axis=0), np.mean(injection, axis=0))
    written = np.array([a @ mean + b - mean for a, b in zip(limits, injection)])
    left = model.left[1:, 1:]
    right = model.R[1:, 1:]
    r0 = right @ right.T

    def ell(x):
        return np.trace(left @ x @ left.T) / 8

    d0 = 1 - la.norm(np.mean(rotations, axis=0), "fro") ** 2 / 8
    terms = [deriv[1:, 1:] @ r0 @ zero.T for deriv, zero in zip(finite, limits)]
    kappa = -ell(np.mean([m + m.T for m in terms], axis=0))
    sym = sym_basis(8)
    twirl = np.mean([o @ sym @ o.T for o in rotations], axis=0)
    t = np.einsum("mij,nij->mn", sym, twirl)
    dimension = la.null_space(np.eye(36) - t, rcond=1e-9).shape[1]
    assert dimension == 1
    return dict(
        beta=float(kappa / d0),
        kappa=float(kappa),
        d0=float(d0),
        writing=float(ell(written.T @ written / 2)),
        fixed_dimension=dimension,
        mean_spectral_radius=float(max(abs(la.eigvals(np.mean(rotations, axis=0))))),
    )


def matched_result(model, eps):
    z = model.unitary_step(0)
    even, odd = [], []
    for e in eps:
        maps = [
            model.left @ model.full_step(e, sign * 8 * np.sqrt(e)) @ model.R
            for sign in (-1, 1)
        ]
        even.append((np.mean(maps, axis=0) - z) / e)
        odd.append((maps[1] - maps[0]) / (2 * np.sqrt(e)))
    derivative = extrapolate(even, eps)
    random = extrapolate(odd, eps)
    # Determine both fixed spaces from unperturbed operators. The six
    # symmetric invariant covariances are not hardcoded into the solve.
    energies, states = la.eigh(model.hdark)
    diag = as_real(model.q.conj().T @ frame([np.outer(x, x.conj()) for x in states.T]))
    rates = diag.T @ derivative @ diag
    assert max(abs(rates.sum(axis=0))) < 1e-7
    pop = la.lstsq(np.vstack((rates, np.ones(3))), np.r_[np.zeros(3), 1.0])[0]
    m = diag @ pop
    o = z[1:, 1:]
    sym = sym_basis(8)
    t = np.einsum("mij,nij->mn", sym, o @ sym @ o.T)
    coords = la.null_space(np.eye(36) - t, rcond=1e-9).T
    assert len(coords) == 6
    invariant = np.einsum("am,mij->aij", coords, sym)
    u = derivative[1:, 1:] @ invariant @ o.T
    kb = np.einsum("aij,bij->ab", invariant, u + u.transpose(0, 2, 1))
    d = random[1:, 1:]
    kt = kb + np.einsum("aij,bij->ab", invariant, d @ invariant @ d.T)
    v = (random @ m)[1:]
    xi = np.einsum("aij,i,j->a", invariant, v, v)
    wc = la.solve(-kb, xi)
    sc = la.solve(-kt, xi)
    readout = as_real(model.q.conj().T @ model.xdark.reshape(-1, order="F"))
    r = np.einsum("aij,i,j->a", invariant, readout[1:], readout[1:])
    signal, variance = r @ wc, r @ sc
    recall = signal / (variance + (1 - (readout @ m) ** 2 - variance) / 1000)
    horizon = brentq(
        lambda x: r @ la.expm(x * kb) @ wc / signal - 0.1, 0, 10, xtol=1e-14
    )
    return dict(
        recall=float(recall),
        horizon=float(horizon),
        variance=float(variance),
        linear_gramian=float(signal),
        fixed_dimension=len(coords),
        phase_separation=float(
            min(
                abs(a - b)
                for a, b in itertools.combinations(
                    [1]
                    + [
                        np.exp(0.5j * (a - b))
                        for i, a in enumerate(energies)
                        for j, b in enumerate(energies)
                        if i != j
                    ],
                    2,
                )
            )
        ),
        max_real_eigenvalue_kb=float(max(la.eigvals(kb).real)),
        max_real_eigenvalue_kt=float(max(la.eigvals(kt).real)),
    )


def compare(seed, ratios):
    # Exact dyadic inputs are read from the package so the rerun does not
    # depend on generating disorder using the same NumPy API.
    model = FullModel([num / den for num, den in ratios])
    coarse = 1.0 / np.array([256.0, 512.0, 1024.0, 2048.0])
    fine = coarse / 2
    return {
        "seed": seed,
        "coarse": {
            "fixed": fixed_result(model, coarse),
            "matched": matched_result(model, coarse),
        },
        "fine": {
            "fixed": fixed_result(model, fine),
            "matched": matched_result(model, fine),
        },
    }
