"""Replay the Appendix C interval calculations and run a separate finite-rate check."""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

import flint
from flint import arb
import numpy as np
import scipy

ROOT = Path(__file__).resolve().parent
SEEDS = [8675309, 424242, 97531, 123457]
SOLVERS = ["certify.py", "certify_matched.py", "matched_limit.json"]
CERTIFICATES = ["certificates.json", "matched_certificates.json"]


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def extra_precision(folder):
    # Same interval algorithm with additional precision. The second method
    # used for the numerical cross-check is exclusively in finite_rate.py.
    sys.path.insert(0, str(folder))
    import certify
    import certify_matched

    flint.ctx.prec = 256
    geometry = certify.geometry()
    fixed = [certify.certify(seed, geometry) for seed in SEEDS]
    starts = {
        x["seed"]: x["x1_scaled_horizon_limit"]
        for x in load(folder / "matched_limit.json")
    }
    matched = [
        certify_matched.make_certificate(seed, geometry, starts[seed]) for seed in SEEDS
    ]
    (folder / "256.json").write_text(json.dumps([fixed, matched], indent=2) + "\n")


def compare_enclosures(x, y):
    # The records include conservative lower bounds and decimal renderings of
    # balls; ensure every reported interval is consistent at the two precisions.
    if isinstance(x, dict):
        require(x.keys() == y.keys(), "Different certificate fields")
        for key in x:
            compare_enclosures(x[key], y[key])
    elif isinstance(x, list):
        require(len(x) == len(y), "Different field lengths")
        for a, b in zip(x, y):
            compare_enclosures(a, b)
    elif isinstance(x, str):
        require(arb(x).overlaps(arb(y)), f"Inconsistent enclosures {x}, {y}")
    else:
        require(x == y, "Mismatched seed, dyadic input or quantile bracket")


def check_claims(fixed, matched):
    for row in fixed:
        require(arb(row["first_moment_4096_power_frobenius"]) < 1, "Mean mixing")
        require(
            arb(row["bordered_twirl_singular_lower"]) > 0, "Simple fixed covariance"
        )
        for key in ["writing", "kappa", "d0", "beta"]:
            require(arb(row[key]) > 0, f"Positive {key}")
        require(
            (arb(row["kappa"]) / arb(row["d0"])).overlaps(arb(row["beta"])),
            "Order rate",
        )
        overlap = arb(row["X1_visibility"])
        require(
            overlap > arb(1) / 7 and overlap.contains(arb(1) / 6),
            "Scalar readout visibility",
        )
    for row in matched:
        require(
            arb(row["min_phase_separation"]) > arb("0.3"), "Isolated coherence phases"
        )
        require(
            arb(row["min_population_offdiag"]) > 0, "Irreducible population generator"
        )
        for key in [
            "hurwitz_determinants_mean_gramian",
            "hurwitz_determinants_covariance",
        ]:
            require(
                len(row[key]) == 6 and all(arb(x) > 0 for x in row[key]),
                "Hurwitz stability",
            )
        for key in [
            "X1_limiting_past_recall",
            "X1_positive_linear_gramian",
            "X1_limiting_variance",
        ]:
            require(arb(row[key]) > 0, key)
        a, b = row["scaled_horizon_bracket"]
        left, right = map(arb, row["scaled_horizon_tail_bounds"])
        require(0 < a < b and b - a < 4.00001e-6, "Horizon bracket width")
        require(left > arb("0.1") and right < arb("0.1"), "Horizon bracket signs")


def evaluate(bridge):
    from finite_rate import compare

    flint.ctx.prec = 256
    with TemporaryDirectory(prefix="spin_certificates_") as tmp:
        fresh = Path(tmp)
        for fname in SOLVERS:
            shutil.copyfile(bridge / fname, fresh / fname)
        for fname in SOLVERS[:2]:
            subprocess.run(
                [sys.executable, str(fresh / fname)],
                cwd=fresh,
                check=True,
                stdout=subprocess.DEVNULL,
            )
        fixed_ref = load(bridge / CERTIFICATES[0])["records"]
        matched_ref = load(bridge / CERTIFICATES[1])["results"]
        replay_hashes = {name: digest(fresh / name) for name in CERTIFICATES}
        fixed = load(fresh / CERTIFICATES[0])["records"]
        matched = load(fresh / CERTIFICATES[1])["results"]
        # Other FLINT builds can print different certified radii. Always check
        # the actual inequalities and overlap, and report byte identity separately.
        compare_enclosures(fixed, fixed_ref)
        compare_enclosures(matched, matched_ref)
        subprocess.run(
            [
                sys.executable,
                str(Path(__file__).resolve()),
                "--extra-precision-worker",
                str(fresh),
            ],
            check=True,
        )
        high_fixed, high_matched = load(fresh / "256.json")
    for records in (fixed, matched, high_fixed, high_matched):
        require([r["seed"] for r in records] == SEEDS, "Expected four specified seeds")
    check_claims(fixed_ref, matched_ref)
    check_claims(fixed, matched)
    check_claims(high_fixed, high_matched)
    compare_enclosures(fixed, high_fixed)
    compare_enclosures(matched, high_matched)
    second = []
    for a, b in zip(fixed, matched):
        trial = compare(a["seed"], a["couplings_as_integer_ratios"])
        trial["errors"] = {}
        for resolution in ("coarse", "fine"):
            f = trial[resolution]["fixed"]
            m = trial[resolution]["matched"]
            errors = {
                "beta": abs(f["beta"] - float(arb(a["beta"]).mid())),
                "recall": abs(
                    m["recall"] - float(arb(b["X1_limiting_past_recall"]).mid())
                ),
            }
            require(
                errors["beta"] < 1e-4 and errors["recall"] < 1e-6,
                "Independent coefficient check",
            )
            for val, ckey in [
                (f["writing"], "writing"),
                (f["kappa"], "kappa"),
                (f["d0"], "d0"),
            ]:
                require(
                    np.isclose(val, float(arb(a[ckey]).mid()), rtol=1e-5),
                    "Fixed coefficient " + ckey,
                )
            lo, hi = b["scaled_horizon_bracket"]
            require(
                lo < m["horizon"] < hi, "Independent horizon outside certified bracket"
            )
            require(
                f["mean_spectral_radius"] < 1
                and m["max_real_eigenvalue_kb"] < 0
                and m["max_real_eigenvalue_kt"] < 0,
                "Independent stability",
            )
            trial["errors"][resolution] = errors
        second.append(trial)
    return {
        "status": "pass",
        "scope": "four declared mixed-sign three-spin Hamiltonians, scalar X1",
        "versions": {
            "python": sys.version.split()[0],
            "python_flint": flint.__version__,
            "numpy": np.__version__,
            "scipy": scipy.__version__,
        },
        "methods": [
            "byte comparison after a fresh 192-bit Arb run",
            "256-bit Arb inequalities and overlap with the 192-bit decimal records",
            "independently implemented finite-rate Richardson extrapolation in a matrix-unit basis",
        ],
        "sha256": {name: digest(bridge / name) for name in SOLVERS + CERTIFICATES},
        "replayed_192_sha256": replay_hashes,
        "byte_identical_192": all(
            replay_hashes[n] == digest(bridge / n) for n in CERTIFICATES
        ),
        "fixed_256": high_fixed,
        "matched_256": high_matched,
        "independent_finite_rate": second,
        "max_fine_absolute_error": {
            k: max(x["errors"]["fine"][k] for x in second) for k in ("beta", "recall")
        },
    }


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "--evidence",
        type=Path,
        default=ROOT.parent,
        help="parent of bridge and certificate_review",
    )
    p.add_argument(
        "--receipt", type=Path, help="optional output path for the verification report"
    )
    p.add_argument("--extra-precision-worker", type=Path, help=argparse.SUPPRESS)
    args = p.parse_args()
    require(__debug__, "Run Python with assertions enabled; omit -O and PYTHONOPTIMIZE")
    if args.extra_precision_worker:
        extra_precision(args.extra_precision_worker)
    else:
        result = evaluate(args.evidence.resolve() / "bridge")
        if args.receipt:
            args.receipt.write_text(json.dumps(result, indent=2) + "\n")
        for row in result["independent_finite_rate"]:
            fine = row["fine"]
            print(
                f"PASS seed {row['seed']}: rate {fine['fixed']['beta']:.7f}, "
                f"recall {fine['matched']['recall']:.9f}, scaled horizon {fine['matched']['horizon']:.9f}"
            )
        print("192-bit records byte-identical:", result["byte_identical_192"])
        print("All 192-bit, 256-bit and independent finite-rate checks passed.")
