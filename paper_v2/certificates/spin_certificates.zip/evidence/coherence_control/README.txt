Causal contrast on coherence across input intervals

Each update starts in the dark qutrit, embeds in the three physical spins,
applies a full finite-loss GKSL step of duration 1/2, and applies the exact
stationary projection of the loss-only semigroup. Arm 1 keeps the resulting
dark state. Arm 2 additionally dephases it in the static dark Hamiltonian
eigenbasis, without keeping a classical record. At the endpoint a physical
X1 measurement gives a binary result. If its conditional mean is x, the
single-shot variance is 1-x^2, using physical X1^2=I, not the square of
the compressed observable. The ideal recovery is part of both controls.
The original unmodified full-spin reservoir has its own finite-rate scores.
No training, actual hardware implementation, cost of performing the recovery,
or comparison against arbitrary classical encoders is assumed.

The protocol/hash records the four known Hamiltonians, all six loss rates,
both interventions and 1000 physical X1 shots per endpoint. From the
extracted numerical environment, run

  python evidence/coherence_control/run.py

This uses certificate_review/finite_rate.py's independent Liouville-space
spin channels and SVD dark coordinates. It solves the stationary moments in
eight real traceless qutrit coordinates, or two diagonal traceless coordinates.
results.json includes the two scores, exact numerical model settings, measured
noise, linear-response Gramian, stationary signal variance and residuals.

From the python-flint certificate environment, run

  python evidence/coherence_control/check_balls.py

This alternate program reconstructs the entire microscopic generator in the
exact orthonormal Pauli basis, recovers the qutrit via its exact dark embedding
and dual stationary map, and uses independently Sturm-isolated dark energies
to construct the energy-population projectors. All exponentials, moment solves
and readout weights are recomputed with 256-bit Arb balls. It checks a positive
adjoint Lyapunov metric with decrement I for each finite-rate arm, so the
stationary covariance is well defined. It encloses 48 population scores
in ball_receipt.json. The double-precision relative discrepancies are largest
where the branch difference is very small at high loss; use the Arb enclosures
for quoting values. Existing interval proofs in the adjacent bridge and
neighborhood_matched folders certify the asymptotic assumptions.

In the dephased channel the input-antisymmetric order-sqrt(epsilon) map has
zero diagonal on every diagonal density: it is the Fréchet derivative of a
unitary step acting on such a density. Simultaneous conjugation by the static
unitary preserves diagonality. Projecting the first-order covariance dynamics
of the mean thus gives I+epsilon(L tensor I + I tensor L), with L the same
irreducible energy-population generator as in the matched proof. On the
zero-sum population subspace, that derivative is Hurwitz. The innovation
variance is O(epsilon^3), and the linear Gramian is O(epsilon^2). The
same-input covariance map differs from the mean-product map by O(epsilon^3),
so the stationary covariance estimate is consistent as well. Projective
shot noise cannot be eliminated by that small signal because every recovered
state is dark-supported and |x|<=sqrt(2/3). The shot-floor statement requires
a fixed positive number of shots. The proofs concern each fixed Hamiltonian
in the specified boxes, rather than asserting a common finite-loss threshold.
