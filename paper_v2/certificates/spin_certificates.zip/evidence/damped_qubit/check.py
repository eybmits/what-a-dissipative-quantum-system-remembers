"""Check the continuous amplitude-damping result using full Lindblad step maps.

The input sign chooses a Z Hamiltonian. The jump relaxes to the +X eigenstate.
The reference uses vectorized 2x2 density matrices and solves moment equations;
the analytic calculation uses a real two-coordinate Bloch exponential.
"""

from pathlib import Path
import json
import numpy as np
from scipy.linalg import expm, solve

HERE = Path(__file__).resolve().parent
I2 = np.eye(2)
X = np.array([[0, 1], [1, 0]], complex)
Y = np.array([[0, -1j], [1j, 0]])
Z = np.diag([1.0, -1.0])
PAULI = [I2, X, Y, Z]
PLUS = np.array([1.0, 1.0]) / np.sqrt(2.0)
MINUS = np.array([1.0, -1.0]) / np.sqrt(2.0)
JUMP = np.outer(PLUS, MINUS)


def lindblad_step(epsilon, angle, sign):
    H = sign * angle * Z / 2
    K = JUMP.conj().T @ JUMP
    generator = -1j * (np.kron(I2, H) - np.kron(H.T, I2)) + epsilon * (
        np.kron(JUMP.conj(), JUMP) - (np.kron(I2, K) + np.kron(K.T, I2)) / 2
    )
    superop = expm(generator)
    basis = np.stack([P.ravel(order="F") for P in PAULI], axis=1) / np.sqrt(2.0)
    pauli = basis.conj().T @ superop @ basis
    assert (
        np.linalg.norm(pauli.imag) < 1e-12
        and np.linalg.norm(pauli[0] - np.array([1, 0, 0, 0])) < 1e-12
    )
    return pauli[1:3, 1:3].real, pauli[1:3, 0].real


def exact(epsilon, angle, shots):
    drift = np.array([[-epsilon, -angle], [angle, -epsilon / 2]])
    E = expm(drift)
    write = np.linalg.solve(drift, (E - np.eye(2)) @ np.array([epsilon, 0.0]))
    a, d, b = E[0, 0], E[1, 1], E[1, 0]
    mean = write[0] / (1 - a)
    v = b * mean + write[1]
    chi = b**4 / ((1 - a * a) * (1 - d * d))
    variance = v * v / ((1 - d * d) * (1 - chi))
    first = 1 - chi
    recall = d * d * first * variance / (variance + (1 - variance) / shots)
    return dict(
        chi=chi,
        mean_order=(1 + chi) / (1 - chi),
        variance=variance,
        recall=recall,
        horizon=np.ceil(np.log(0.1) / np.log(d * d)),
    )


def population(epsilon, theta, shots):
    maps = [lindblad_step(epsilon, theta, u) for u in (-1, 1)]
    A = (maps[0][0] + maps[1][0]) / 2
    D = (maps[1][0] - maps[0][0]) / 2
    m = solve(np.eye(2) - A, (maps[0][1] + maps[1][1]) / 2)
    v = D @ m + (maps[1][1] - maps[0][1]) / 2
    V = np.outer(v, v).ravel()
    B = np.kron(A, A)
    T = B + np.kron(D, D)
    sigma = solve(np.eye(4) - T, V)
    G1 = solve(np.eye(4) - B, V)
    F = solve(np.eye(4) - B, T - B)
    Q = solve(np.eye(4) - F, sigma)
    past = (A @ G1.reshape(2, 2) @ A.T)[1, 1]
    vary = sigma[3]
    return dict(
        variance=vary, mean_order=Q[3] / vary, recall=past / (vary + (1 - vary) / shots)
    )


def main():
    rows = []
    worst = 0.0
    for e in (0.2, 0.05, 0.01, 0.003, 0.001):
        for a in (0, 0.25, 0.5, 0.75, 1.0):
            theta = 0.8 * e**a
            expected = exact(e, theta, 100)
            actual = population(e, theta, 100)
            diff = max(
                abs(actual[k] - expected[k]) / max(abs(expected[k]), 1e-15)
                for k in actual
            )
            worst = max(worst, diff)
            rows.append(
                dict(epsilon=e, theta=theta, power=a, **expected, relative_check=diff)
            )
    if worst > 1e-7:
        raise ArithmeticError(worst)
    k = 0.64
    limiting_variance = 4 * k / ((k + 2) * (3 * k + 2))
    limit_recall = (
        (1 - k * k / ((k + 1) * (k + 2)))
        * limiting_variance
        / (limiting_variance + (1 - limiting_variance) / 100)
    )
    e = 1e-6
    q = exact(e, np.sqrt(k * e), 100)
    fixed = exact(e, 0.8, 100)
    assert (
        abs(q["recall"] - limit_recall) < 1e-4
        and abs(e * q["horizon"] - np.log(10) / (1 + k)) < 1e-4
    )
    assert abs(e * fixed["mean_order"] - 2 * np.sin(0.8) ** 2 / 3) < 1e-4
    out = dict(
        rows=rows,
        max_relative_difference=worst,
        matched_limit_recall=limit_recall,
        matched_limit_variance=limiting_variance,
        horizon_coefficient=np.log(10) / (1 + k),
        fixed_beta=3 / (2 * np.sin(0.8) ** 2),
    )
    (HERE / "check.json").write_text(json.dumps(out, indent=2) + "\n")
    print(
        "25 maps, three independently checked quantities per map; max relative discrepancy",
        worst,
    )


if __name__ == "__main__":
    main()
