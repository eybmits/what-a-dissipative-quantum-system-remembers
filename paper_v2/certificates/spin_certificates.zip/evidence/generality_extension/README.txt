Matched-drive criterion and a three-level realization

From the extracted evidence root run

  python evidence/generality_extension/check_lambda.py

The calculation uses only NumPy and SciPy. It reconstructs the actual
three-level Lambda Hamiltonians in the broader model panel independently,
using a trace-orthonormal Hermitian basis and dense discrete stationary
moment equations for each full finite-rate map. The generator is formed
by its action on each basis matrix. The measured observable Y_D is the
doublet Pauli Y extended by zero on the bright level, with 1000 shots.
Spin seeds, step time, drive normalization, continuous detuning and
bright-branch probabilities are specified in the script and manuscript.

lambda_validation.json compares the analytic mass and horizon limits with
full finite-rate moments at gamma=1024, 16384 and 262144. The eight seed
parameters and coefficients g=2,8,32 give 72 comparisons. Rates, couplings,
limits and the writing test are supplied at full machine-readable precision.
The endpoint comparison tests a finite-rate approximation to the derived
limit; the analytic argument in the manuscript establishes the limit for
the stated parameter family. The example hz=6/5, g0=1/2, g1=1 lies on the
exact zero-writing surface. Its limiting past mass is zero and there is no
limiting positive-mass horizon in that case. The very small finite-rate
control scores at the largest rates are sensitive to numerical cancellation.

The general proposition applies when the leading writing, projected covariance
stability, observability and uniform boundedness conditions in the manuscript
hold. It does not claim that all open quantum systems obey this law.
