"""Compare the analytic dark-doublet formulas with stationary full-qutrit maps."""

from pathlib import Path
import json

import numpy as np
from scipy import linalg

HERE = Path(__file__).resolve().parent
SEEDS = [
    1859803859,
    3370192539,
    1164988649,
    2725577964,
    1915480706,
    451875653,
    368553518,
    904190909,
]
H = 0.5
SHOTS = 1000


def parameters(seed):
    rng = np.random.default_rng(seed)
    return [rng.uniform(0.65, 1.35), rng.uniform(-0.5, 0.5), *rng.uniform(0.4, 1.1, 2)]


def limits(params, c):
    hz, _, g0, g1 = params
    w = np.hypot(1.5, hz)
    n = np.array([1.5, 0, hz]) / w
    q = g0 * g0 + g1 * g1
    b = np.array([2 * g0 * g1, 0, g0 * g0 - g1 * g1])
    t = np.array([0.0, 0, 0.4])
    loss = 2 * (np.outer(t, b) - q * np.eye(3))
    s = -H * (n @ loss @ n)
    r = -H * (np.trace(loss) - n @ loss @ n) / 2
    a = (c * np.sin(H * w / 2) / w) ** 2
    injection = 2 * H * (n @ (q * t - b))
    pop = injection / (s + a / 2)
    damping = 2 * r + a / 2
    source = a * pop * pop
    gram = 0.5 * source / damping
    variance = 0.5 * source / (damping - a * a / (2 * (2 * s + a)))
    recall = gram / (variance + (1 - variance) / SHOTS)
    return dict(
        recall=float(recall),
        scaled_horizon=float(np.log(10) / damping),
        writing=float(injection),
        scalar_variance=float(variance),
    )


def operators():
    unit = np.eye(3)
    e = [np.outer(v, v) for v in unit]
    herm = [
        unit / np.sqrt(3),
        (e[0] - e[1]) / np.sqrt(2),
        (e[0] + e[1] - 2 * e[2]) / np.sqrt(6),
    ]
    for i, j in [(0, 1), (0, 2), (1, 2)]:
        cross = np.outer(unit[i], unit[j])
        herm.extend(
            [(cross + cross.T) / np.sqrt(2), -1j * (cross - cross.T) / np.sqrt(2)]
        )
    return e, herm


def direct(params, gamma, c):
    hz, detuning, g0, g1 = params
    projectors, herm = operators()
    ket = np.eye(3)
    cross = lambda i, j: np.outer(ket[i], ket[j])
    y = -1j * (cross(0, 1) - cross(1, 0))
    dark = projectors[0] + projectors[1]
    static = (
        hz * (projectors[0] - projectors[1]) / 2
        + 0.75 * (cross(0, 1) + cross(1, 0))
        + detuning * projectors[2]
    )
    static += g0 * (cross(0, 2) + cross(2, 0)) + g1 * (cross(1, 2) + cross(2, 1))
    branches = []
    for sign in (-1, 1):
        ham = static + sign * c * y / (4 * np.sqrt(gamma))
        cols = []
        for v in herm:
            deriv = -1j * (ham @ v - v @ ham)
            for j, prob in enumerate([0.7, 0.3]):
                jump = cross(j, 2)
                deriv += (
                    gamma
                    * prob
                    * (jump @ v @ jump.T - (projectors[2] @ v + v @ projectors[2]) / 2)
                )
            cols.append([np.trace(u @ deriv).real for u in herm])
        step = linalg.expm(H * np.array(cols).T)
        branches.append((step[1:, 1:], step[1:, 0] / np.sqrt(3)))
    (am, bm), (ap, bp) = branches
    A, D = (am + ap) / 2, (ap - am) / 2
    m = linalg.solve(np.eye(8) - A, (bp + bm) / 2)
    innovation = D @ m + (bp - bm) / 2
    inj = np.outer(innovation, innovation)
    cov = linalg.solve(np.eye(64) - np.kron(A, A) - np.kron(D, D), inj.ravel()).reshape(
        8, 8
    )
    w0 = linalg.solve(np.eye(64) - np.kron(A, A), inj.ravel()).reshape(8, 8)
    past = A @ w0 @ A.T
    obs = np.array([np.trace(u @ y).real for u in herm[1:]])
    state = sum(r * u for r, u in zip(np.r_[1 / np.sqrt(3), m], herm))
    var = obs @ cov @ obs
    disp = np.trace(dark @ state).real - (obs @ m) ** 2
    den = var + (disp - var) / SHOTS
    if not den > 0:
        raise ArithmeticError("nonpositive observed variance")
    signal = obs @ past @ obs

    def frac(after):
        row = obs @ np.linalg.matrix_power(A, after)
        return row @ past @ row / signal

    lower, upper = 0, 1
    while frac(upper) > 0.1:
        upper *= 2
    while upper - lower > 1:
        mid = (upper + lower) // 2
        if frac(mid) > 0.1:
            lower = mid
        else:
            upper = mid
    return dict(
        recall=float(signal / den),
        horizon=int(upper),
        scaled_horizon=float(upper / gamma),
    )


def main():
    rows = []
    rates = [1024, 16384, 262144]
    for seed in SEEDS:
        p = parameters(seed)
        for c in (2, 8, 32):
            expected = limits(p, c)
            actual = [{"gamma": g, **direct(p, g, c)} for g in rates]
            rows.append(
                {"seed": seed, "params": p, "c": c, "limit": expected, "finite": actual}
            )
    relative = {
        key: max(abs(r["finite"][-1][key] / r["limit"][key] - 1) for r in rows)
        for key in ("recall", "scaled_horizon")
    }
    control = [1.2, 0.0, 0.5, 1.0]
    # Here hz=6/5 exactly satisfies the zero-writing equation.
    # The normalized horizon has no positive-mass limit to quantify.
    ctrl = {
        "params": control,
        "limiting_recall": 0,
        "limiting_horizon": None,
        "finite": [{"gamma": g, **direct(control, g, 8)} for g in rates],
    }
    if max(relative.values()) > 0.001 or ctrl["finite"][-1]["recall"] >= 1e-5:
        raise ArithmeticError((relative, ctrl))
    data = {
        "model": "trinary Y_D, stationary population, independent full-qutrit check",
        "shots": SHOTS,
        "time_step": H,
        "rows": rows,
        "endpoint_max_relative_error": relative,
        "zero_writing_control": ctrl,
    }
    (HERE / "lambda_validation.json").write_text(json.dumps(data, indent=2) + "\n")
    print("Endpoint maximum relative comparisons:", relative)
    print("Control recalls:", [r["recall"] for r in ctrl["finite"]])
    for r in rows[1::3]:
        print(
            r["seed"],
            r["limit"]["writing"],
            r["limit"]["recall"],
            r["limit"]["scaled_horizon"],
        )


if __name__ == "__main__":
    main()
