"""Certify closed coupling boxes for the fixed-drive order law. No sampling.

Run with python-flint 0.9.0 and NumPy. The neighboring bridge/certify.py
supplies the exact dyadic Pauli geometry, dark projection and reduced inverse.
"""
import argparse
import itertools
import json
from pathlib import Path
import sys

import flint
from flint import arb, arb_mat as M

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "bridge"))
import certify as base

HALF = arb(1) / 32
MAX_DEPTH = 7
DARK = range(1, 9)
COORDS = [(i, j) for i in range(8) for j in range(i + 1)]
SQRT2 = arb(2).sqrt()
IDENTITY_AXIS = M([[int(i == j) / arb(8).sqrt()] for i, j in COORDS])


def geometric_data():
    _, embed, dual, reduced_inv, static, drive, pairs = base.geometry()
    labels = list(itertools.product(range(4), repeat=3))
    data = []
    for sign in (-1, 1):
        terms = [static + sign * drive, *pairs]
        energies = [M(64, 1) for _ in terms]
        for i in range(3):
            for code, coefficient in [(1, arb(3 + sign) / 4), (3, arb(1) / 2)]:
                word = [0] * 3
                word[i] = code
                energies[0][labels.index(tuple(word)), 0] = coefficient
        for vector, (i, j) in zip(energies[1:], itertools.combinations(range(3), 2)):
            word = [0] * 3
            word[i] = word[j] = 1
            vector[labels.index(tuple(word)), 0] = 1
        # A common factor sqrt(8) cancels in the normalized energy witness.
        axes = [base.block(embed.transpose() * e, DARK, [0]) for e in energies]
        generators = [dual * h * embed / 2 for h in terms]
        right = [reduced_inv * h * embed for h in terms]
        left = [-dual * h / 2 for h in terms]
        corrections = []
        for i in range(4):
            for j in range(i + 1):
                c = left[i] * right[j]
                if j != i:
                    c += left[j] * right[i]
                corrections.append((i, j, c))
        data.append((axes, generators, corrections))
    return data


def linear(terms, parameters):
    return terms[0] + sum((j * t for j, t in zip(parameters, terms[1:])), M(terms[0].nrows(), terms[0].ncols()))


def central_coercivity(parameters, data):
    """Lower-bound ||((I-T_-),(I-T_+)) X/2|| on unit trace-free X."""
    rotations = [base.block(linear(gens, parameters).exp(), DARK, DARK) for _, gens, _ in data]
    n = len(COORDS)
    twirl = M(n, n)
    for col, (i, j) in enumerate(COORDS):
        matrix = M(8, 8)
        matrix[i, j] = matrix[j, i] = 1 if i == j else 1 / SQRT2
        image = sum((o * matrix * o.transpose() for o in rotations), M(8, 8)) / 2
        for row, (a, b) in enumerate(COORDS):
            twirl[row, col] = image[a, b] * (1 if a == b else SQRT2)
    gram = base.eye(n) - (twirl + twirl.transpose()) / 2 + IDENTITY_AXIS * IDENTITY_AXIS.transpose()
    return (1 / base.frob(gram.inv())).sqrt()


def uniform_bounds(center, radius, data):
    gap = central_coercivity(center, data) - arb(18).sqrt() * radius
    if not gap > 0:
        return None
    parameters = [arb(j, radius) for j in center]
    factors = [arb(1), *parameters]
    rotations, corrections, writing = [], [], []
    for axes, gens, coeff in data:
        g = linear(gens, parameters)
        k = sum((factors[i] * factors[j] * v for i, j, v in coeff), M(9, 9))
        aug = M(18, 18)
        for i in range(9):
            for j in range(9):
                aug[i, j] = aug[i + 9, j + 9] = g[i, j]
                aug[i, 9 + j] = k[i, j]
        exp = aug.exp()
        rotations.append(base.block(exp, DARK, DARK))
        corrections.append(base.block(exp, DARK, range(10, 18)))
        axis = linear(axes, parameters)
        innovation_energy = (axis.transpose() * base.block(k, DARK, [0]))[0, 0] / arb(3).sqrt()
        writing.append(innovation_energy.abs_lower()**2 / (8 * sum(x.abs_upper()**2 for x in axis.entries())))
    write = max(v.lower() for v in writing)
    kappa = -sum((f * o.transpose()).trace() for f, o in zip(corrections, rotations)) / 8
    diff = (rotations[1] - rotations[0]).entries()
    d_low = sum(x.abs_lower()**2 for x in diff) / 32
    d_high = sum(x.abs_upper()**2 for x in diff) / 32
    if not (write > 0 and kappa > 0 and d_low > 0):
        return None
    return [gap.lower(), write, kappa.lower(), d_low.lower(), (kappa / d_low).upper(),
            (kappa / d_high).lower(), kappa.upper(), d_high.upper()]


def rounded(x, upper=False):
    unit = 10**9
    y = x * unit
    integer = int((y.upper().ceil() if upper else y.lower().floor()).unique_fmpz())
    return f"{'-' if integer < 0 else ''}{abs(integer) // unit}.{abs(integer) % unit:09d}"


def certify_box(record, data):
    center = tuple(arb(n) / d for n, d in record["couplings_as_integer_ratios"])
    todo = [(center, HALF, 0)]
    bounds, depths = [], []
    while todo:
        subcenter, radius, depth = todo.pop()
        result = uniform_bounds(subcenter, radius, data)
        if result is not None:
            bounds.append(result)
            depths.append(depth)
        elif depth < MAX_DEPTH:
            h = radius / 2
            todo.extend((tuple(x + s*h for x, s in zip(subcenter, signs)), h, depth + 1)
                        for signs in itertools.product((-1, 1), repeat=3))
        else:
            raise ArithmeticError(f"Uncertified box at seed {record['seed']}, depth {depth}")
    # Each bisection generated all eight closed children. Check coverage also by volume.
    assert sum(8**(MAX_DEPTH - d) for d in depths) == 8**MAX_DEPTH
    values = list(zip(*bounds))
    return dict(seed=record["seed"], center_ratios=record["couplings_as_integer_ratios"],
                leaves_by_depth={d: depths.count(d) for d in sorted(set(depths))},
                commutator_lower=rounded(min(values[0])), writing_lower=rounded(min(values[1])),
                kappa_bounds=[rounded(min(values[2])), rounded(max(values[6]), True)],
                d0_bounds=[rounded(min(values[3])), rounded(max(values[7]), True)],
                beta_bounds=[rounded(min(values[5])), rounded(max(values[4]), True)])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--receipt", type=Path, default=HERE / "receipt.json")
    options = parser.parse_args()
    reference = json.loads((HERE.parent / "bridge" / "certificates.json").read_text())
    data = geometric_data()
    records = []
    for record in reference["records"]:
        item = certify_box(record, data)
        records.append(item)
        print(json.dumps(item), flush=True)
    result = dict(precision_bits=flint.ctx.prec, python_flint=flint.__version__,
                  domain="Closed boxes in (J12, J13, J23), all other terms fixed; pointwise loss-rate limit.",
                  half_width_exact=str(HALF), records=records)
    options.receipt.write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
