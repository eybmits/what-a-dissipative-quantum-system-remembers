Matched-drive neighborhood certificate

Run in the pinned certificate environment with normal Python (assertions on):

  python evidence/neighborhood_matched/verify.py --receipt matched-boxes.json
  python evidence/neighborhood_matched/verify.py --bits 512 --receipt matched-boxes-512.json

The first command uses 256-bit Arb balls. Add --cells to record every individual
accepted subcell; the default receipt records the componentwise half-width,
exact centers, counts by depth and certified minima for each Hamiltonian.
Both precision runs cover four closed three-dimensional boxes of half-width
1/512. All endpoints are exact dyadic numbers. The eight equal octants cover
every cell rejected by a sufficient test. The final dyadic volume sum is
checked. The prescribed prefactor is 8 and the readout uses 1000 X1 shots.

The certificate rebuilds the compressed static Hamiltonian at each cell
center. Its eigenvalue brackets have exact Sturm count one for the independently
constructed rational cubic; floating eigenvalues only suggest where to put
these brackets. In a radius-r cell the compressed Hamiltonian changes by
operator norm at most 3r. For a central spectral gap s>3r, projecting the
perturbed eigenvector equation onto the other two central eigenvectors
bounds the sine of its angle to the original eigenline by 3r/(s-3r).
That sine is the spectral norm of the rank-one projector difference.
The code interval-evaluates the resulting six-mode invariant covariance basis,
the microscopic augmented matrix exponential and the two projected generators.
Separated coherence phases preserve exactly this basis dimension for every
coupling in a cell. Positive LDL pivots for both negative symmetric parts
prove strict stability. A population transition off the diagonal starts at
zero in the positive trace-preserving channel, so its first derivative is
nonnegative. Three positive directed tree weights certify irreducibility
and give the normalized stationary populations.

On the dark space the drive Hamiltonian at unit gain equals the restricted
X1 divided by two, and X1 has eigenvalues 0 and +/- sqrt(2/3). The innovation
at stationary population p has zero diagonal. For energy pair i,j of gap d,
its off-diagonal modulus is |vij|=4|pi-pj| |Xij| |exp(i d/2)-1|/|d|.
The real two-dimensional coherence plane contributes its identity to the
invariant covariance space. K_B maps its identity into itself after projection:
a single first-order perturbation changes one index of the covariance,
so cannot generate a different diagonal block. If k is the corresponding
diagonal entry of K_B, the visible contribution is 2|Xij vij|^2/(-k).
The remaining invariant covariance contributions are nonnegative. For a
rank-one energy block, the Frobenius norm of Pi X1 Pj equals |Xij|.
At least one strictly positive contribution is certified on every cell.

For a physical conditional state supported on the dark space, a single X1
shot has conditional variance at least 1/3. This applies in the limit since
the stationary mean has dark support and a limiting distribution of positive
states with that mean is almost surely dark-supported. The measured scalar
variance at 1000 shots is positive and at most one. An optional sharper
upper bound uses ||a||_2^2=4/3 and
  a^T Sigma a <= (4/3) ||(-K_T)^(-1)||_F ||v||_2^2.
Indeed the fixed covariance basis is Frobenius-orthonormal, and projection
of vv^T cannot increase its Frobenius norm. The extra noise term in the
measured denominator is at most 1/1000. A cell falls back to the bound one
whenever interval inversion does not improve it. The verified worst-case
limiting recall exceeds 5e-8 in every box. The sharper center values are in
the manuscript; the box bound is a conservative lower bound.

As shown in the paper, the normalized limiting tail is analytic,
nonincreasing, starts at one, and tends to zero. It crosses one tenth at a
unique finite positive time. This establishes the horizon limit throughout
the boxes without a finite-loss threshold or a common numerical horizon.
