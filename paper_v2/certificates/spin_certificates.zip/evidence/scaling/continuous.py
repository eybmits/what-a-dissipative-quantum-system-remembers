"""Enclose Appendix C's matched-drive positivity conditions for 2 <= c <= 32."""

import hashlib
import itertools
import json
from math import comb
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "bridge"))
import numpy as np
import flint
from flint import arb, acb, arb_mat as M
from certify import block, geometry, eye, exact, interval
from certify_matched import cmatrix, gram, hamiltonian, qutrit_basis


def block_exp(G, J, C):
    aug = M(27, 27)
    for i in range(9):
        for j in range(9):
            for k in range(3):
                aug[9 * k + i, 9 * k + j] = G[i, j]
            aug[i, 9 + j] = aug[9 + i, 18 + j] = J[i, j]
            aug[i, 18 + j] = C[i, j]
    return aug.exp()


def sector(seed, geom):
    _, R, LT, S, Hbase, Hdrive, xx = geom
    H = Hbase + sum(
        (
            exact(j) * h
            for j, h in zip(np.random.default_rng(seed).uniform(-1, 1, 3), xx)
        ),
        M(64, 64),
    )
    Hd, Xd = hamiltonian(seed)
    energies = sorted((z.real for z in Hd.eig()), key=lambda z: float(z.mid()))
    assert all(energies[i] < energies[i + 1] for i in range(2))
    phases = [acb(1)] + [
        acb(0, (a - b) / 2).exp()
        for i, a in enumerate(energies)
        for j, b in enumerate(energies)
        if i != j
    ]
    sep = min(abs(a - b).lower() for a, b in itertools.combinations(phases, 2))
    assert sep > arb(".3")
    projectors = []
    for i, ei in enumerate(energies):
        p = eye(3)
        for j, ej in enumerate(energies):
            if i != j:
                p = p * (Hd - ej * eye(3)) / (ei - ej)
        projectors.append(cmatrix(p))
    tb = qutrit_basis()
    proj = M([[(t * p).trace().real for p in projectors] for t in tb])
    va = (block(proj, range(1, 9), [0]) - block(proj, range(1, 9), [1])) / arb(2).sqrt()
    vb = (
        block(proj, range(1, 9), [0])
        + block(proj, range(1, 9), [1])
        - 2 * block(proj, range(1, 9), [2])
    ) / arb(6).sqrt()
    basis = [
        va * va.transpose(),
        vb * vb.transpose(),
        (va * vb.transpose() + vb * va.transpose()) / arb(2).sqrt(),
    ]
    for pi, pj in itertools.combinations(projectors, 2):
        plane = M(
            [
                [(ta * (pi * t * pj + pj * t * pi)).trace().real for t in tb[1:]]
                for ta in tb[1:]
            ]
        )
        basis.append(plane / arb(2).sqrt())
    readout = M([[(t * cmatrix(Xd)).trace().real] for t in tb])
    a = block(readout, range(1, 9), [0])
    aw = M([[gram(y, a * a.transpose()) for y in basis]])
    G = LT * H * R / 2
    J = LT * Hdrive * R / 2
    C = -LT * H * S * H * R / 2
    zero = M(9, 9)
    base = block_exp(G, zero, C)
    drive = block_exp(G, J, zero)
    E = block(base, range(9), range(9))
    E0 = block(base, range(9), range(18, 27))
    E2 = block(drive, range(9), range(18, 27))
    D1 = block(drive, range(9), range(9, 18))
    O = block(E, range(1, 9), range(1, 9))
    d = block(D1, range(1, 9), range(1, 9))

    def secular(e):
        e = block(e, range(1, 9), range(1, 9))
        return M(
            [
                [gram(v, e * w * O.transpose() + O * w * e.transpose()) for w in basis]
                for v in basis
            ]
        )

    B0, B2 = secular(E0), secular(E2)
    T2 = B2 + M([[gram(v, d * w * d.transpose()) for w in basis] for v in basis])
    return (
        proj.transpose() * E0 * proj,
        proj.transpose() * E2 * proj,
        D1 * proj,
        B0,
        B2,
        T2,
        basis,
        aw,
        readout.transpose() * proj,
        sep,
    )


def hurwitz(K):
    q = K.charpoly()
    n = K.nrows()
    coeff = [q[n - i] for i in range(n + 1)]
    H = M(
        [
            [coeff[2 * j - i + 1] if 0 <= 2 * j - i + 1 <= n else 0 for j in range(n)]
            for i in range(n)
        ]
    )
    return [block(H, range(k), range(k)).det() for k in range(1, n + 1)]


def replace_column(A, j, col):
    return M(
        [
            [col[i, 0] if k == j else A[i, k] for k in range(A.ncols())]
            for i in range(A.nrows())
        ]
    )


def positivity_polynomials(sector, x, return_score=False):
    C0, C2, Dp, B0, B2, T2, basis, aw, mean_row, _ = sector
    C = C0 + x * C2
    off = [C[i, j] for i in range(3) for j in range(3) if i != j]
    P = M([[C[i, j] if i < 2 else 1 for j in range(3)] for i in range(3)])
    rhs = M([[0], [0], [1]])
    # det(P) p_* is polynomial of degree <=2. Its sign does not matter:
    # the projected covariance below is multiplied by det(P)^2.
    pnum = M([[replace_column(P, j, rhs).det()] for j in range(3)])
    vnum = block(Dp * pnum, range(1, 9), [0])
    write = x * M([[gram(b, vnum * vnum.transpose())] for b in basis])
    B, T = B0 + x * B2, B0 + x * T2

    def numerator(K):
        # det(-K)>0 by strict Hurwitz stability. Its Cramer numerators
        # supply a polynomial of degree <=10 for the visible scalar mass.
        return sum(
            (aw[0, j] * replace_column(-K, j, write).det() for j in range(6)), arb(0)
        )

    nw, ns = numerator(B), numerator(T)
    if return_score:
        detpop = P.det()
        w = nw / (detpop**2 * (-B).det())
        variance = ns / (detpop**2 * (-T).det())
        mean = (mean_row * pnum)[0, 0] / detpop
        return w / (variance + (1 - mean**2 - variance) / 1000)
    return off + hurwitz(B) + hurwitz(T) + [nw, ns]


def divide(coeff):
    levels = [coeff]
    while len(levels[-1]) > 1:
        old = levels[-1]
        levels.append([(a + b) / 2 for a, b in zip(old, old[1:])])
    return [s[0] for s in levels], [s[-1] for s in reversed(levels)]


def check(seed, geom):
    q = sector(seed, geom)
    n = 21
    # Distinct exact rational t nodes, Bernstein basis at those same nodes.
    t = [arb(j) / n for j in range(n + 1)]
    A = M([[comb(n, k) * u**k * (1 - u) ** (n - k) for k in range(n + 1)] for u in t])
    values = M([positivity_polynomials(q, 4 + 1020 * u) for u in t])
    coef = A.solve(values)
    boxes = []

    def visit(a, b, polys, depth):
        lower = [
            min(z.lower() for z in col) if all(z > 0 for z in col) else None
            for col in polys
        ]
        if all(z is not None for z in lower):
            boxes.append(
                dict(
                    x=[a, b],
                    positive=True,
                    lower_bounds=[interval(z.lower()) for z in lower],
                )
            )
        elif depth >= 12:
            boxes.append(dict(x=[a, b], positive=False))
        else:
            children = [divide(col) for col in polys]
            visit(a, (a + b) / 2, [s[0] for s in children], depth + 1)
            visit((a + b) / 2, b, [s[1] for s in children], depth + 1)

    polys = [[coef[k, j] for k in range(n + 1)] for j in range(coef.ncols())]
    visit(4, 1024, polys, 0)
    records = json.loads((HERE / "prefactor_certificates.json").read_text())["rows"]
    point_checks = {}
    for row in records:
        if row["seed"] == seed and row["bits"] == 256:
            g = row["coefficient"]
            score = positivity_polynomials(q, arb(g) ** 2, return_score=True)
            assert score.overlaps(arb(row["X1_limiting_past_recall"]))
            point_checks[str(g)] = interval(score)
    assert len(point_checks) == 5
    return dict(
        seed=seed,
        min_phase_separation=interval(q[-1]),
        boxes=boxes,
        individual_score_checks=point_checks,
    )


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Enable Python assertions")
    flint.ctx.prec = 256
    geom = geometry()
    seeds = json.loads((HERE / "protocol.json").read_text())["seeds"]
    output = {
        "precision_bits": 256,
        "python_flint": flint.__version__,
        "protocol_sha256": hashlib.sha256(
            (HERE / "continuous_protocol.json").read_bytes()
        ).hexdigest(),
        "polynomial_order": [
            "population offdiagonals (row major, skip diagonal)",
            "six K_B Hurwitz minors",
            "six K_T Hurwitz minors",
            "scaled observable numerator for W",
            "scaled observable numerator for Sigma",
        ],
        "seeds": [],
    }
    for seed in seeds:
        report = check(seed, geom)
        output["seeds"].append(report)
        print(
            seed,
            len(report["boxes"]),
            sum(not b["positive"] for b in report["boxes"]),
            flush=True,
        )
    (HERE / "continuous_certificate.json").write_text(
        json.dumps(output, indent=2) + "\n"
    )
    assert all(box["positive"] for r in output["seeds"] for box in r["boxes"])
