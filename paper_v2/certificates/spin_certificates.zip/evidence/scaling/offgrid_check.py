"""Check gain coefficients between the five tabulated values with finite-rate full maps."""

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "certificate_review"))
sys.path.insert(0, str(HERE.parent / "bridge"))
from finite_rate import FullModel, matched_result
from matched import matched


def crosscheck():
    seeds = json.loads((HERE.parent / "bridge/certificates.json").read_text())[
        "records"
    ]
    eps = 1 / np.array([512.0, 1024.0, 2048.0, 4096.0])
    rows = []
    for record in seeds:
        seed = record["seed"]
        couplings = [n / d for n, d in record["couplings_as_integer_ratios"]]
        for c in (3, 12, 24):
            model = FullModel(couplings)
            # The independent solver uses 8 sqrt(eps) times its drive operator.
            model.drive *= c / 8
            model.udark *= c / 8
            numeric = matched_result(model, eps)
            secular = matched(seed, gain_scale=c)
            row = {
                "seed": seed,
                "coefficient": c,
                "extrapolated_recall": numeric["recall"],
                "secular_recall": secular["x1_population_recall_limit"],
                "extrapolated_scaled_horizon": numeric["horizon"],
                "secular_scaled_horizon": secular["x1_scaled_horizon_limit"],
            }
            rows.append(row)
    recall_error = max(
        abs(r["extrapolated_recall"] - r["secular_recall"]) for r in rows
    )
    horizon_error = max(
        abs(r["extrapolated_scaled_horizon"] - r["secular_scaled_horizon"])
        for r in rows
    )
    if not all(
        np.isfinite(list(r.values())).all()
        and r["extrapolated_recall"] > 0
        and r["extrapolated_scaled_horizon"] > 0
        for r in rows
    ):
        raise ValueError("Invalid independent finite-rate estimate.")
    return {
        "rows": rows,
        "maximum_absolute_recall_difference": recall_error,
        "maximum_absolute_scaled_horizon_difference": horizon_error,
    }


if __name__ == "__main__":
    results = crosscheck()
    (HERE / "offgrid_check.json").write_text(json.dumps(results, indent=2) + "\n")
    print({k: v for k, v in results.items() if k != "rows"})
