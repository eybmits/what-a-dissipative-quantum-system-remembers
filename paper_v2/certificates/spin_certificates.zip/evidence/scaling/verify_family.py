"""Recheck matched gain throughout the prescribed coefficient interval."""

import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory

import flint
from flint import arb

from certify_prefactors import run
from continuous import check, geometry
from offgrid_check import crosscheck

HERE = Path(__file__).resolve().parent


def verify():
    if not __debug__:
        raise RuntimeError("Interval verification requires an interpreter without -O.")
    with TemporaryDirectory() as directory:
        target = Path(directory) / "certificates.json"
        run(target)
        point = json.loads(target.read_text())
    expected = json.loads((HERE / "prefactor_certificates.json").read_text())
    reference = {(r["seed"], r["coefficient"], r["bits"]): r for r in expected["rows"]}
    if len(reference) != 40 or len(point["rows"]) != 40:
        raise RuntimeError("Missing pointwise gain or precision.")
    for rec in point["rows"]:
        prior = reference[rec["seed"], rec["coefficient"], rec["bits"]]
        if not arb(prior["X1_limiting_past_recall"]).overlaps(
            arb(rec["X1_limiting_past_recall"])
        ):
            raise RuntimeError("Inconsistent recall enclosure.")
    seeds = json.loads((HERE / "protocol.json").read_text())["seeds"]
    checks = {}
    for bits in (256, 512):
        flint.ctx.prec = bits
        base = geometry()
        reports = [check(seed, base) for seed in seeds]
        for report in reports:
            edge = 4
            for box in report["boxes"]:
                left, right = box["x"]
                if (
                    left != edge
                    or right <= left
                    or not box["positive"]
                    or len(box["lower_bounds"]) != 20
                    or not all(arb(z) > 0 for z in box["lower_bounds"])
                ):
                    raise RuntimeError(
                        "Incomplete interval or a failed positivity certificate."
                    )
                edge = right
            if edge != 1024:
                raise RuntimeError("The certified interval falls short of c=32.")
        checks[str(bits)] = [r["seed"] for r in reports]
    direct = crosscheck()
    if (
        max(
            direct["maximum_absolute_recall_difference"],
            direct["maximum_absolute_scaled_horizon_difference"],
        )
        > 1e-6
    ):
        raise RuntimeError("Independent finite-rate comparison failed.")
    return {
        "scalar_readout": "X1, 1000 shots",
        "coefficient_range": [2, 32],
        "square_grid_records": len(reference),
        "bernstein_intervals": checks,
        "independent_off_grid": direct,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--receipt", type=Path)
    args = parser.parse_args()
    result = verify()
    if args.receipt:
        args.receipt.write_text(json.dumps(result, indent=2) + "\n")
    print("All four Hamiltonians pass over 2 <= c <= 32 at 256 and 512 bits.")
    print(
        "Twelve off-grid limiting recalls and horizons agree with the independent full-map extrapolation."
    )
