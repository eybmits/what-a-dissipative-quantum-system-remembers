#!/usr/bin/env python3
"""Independent population reconstruction from the equations and seeds in V2 Appendix H.

Run with Python, NumPy, and SciPy. There is no need to sample input histories.
The Table 3 source transcription is used only by check_endpoints.py after the run.
"""
import argparse
import csv
import itertools
from pathlib import Path
import numpy as np
import scipy.linalg as la
from scipy.sparse.linalg import LinearOperator, gmres

HERE = Path(__file__).resolve().parent
SEEDS = (8675309, 424242, 97531, 123457)
RATES = (64, 256, 1024, 4096, 16384)
SHOTS = 1000
PAULI = (np.eye(2), np.array([[0, 1], [1, 0]]),
         np.array([[0, -1j], [1j, 0]]), np.diag([1, -1]))


def tensor(factors):
    result = np.ones((1, 1))
    for item in factors:
        result = np.kron(result, item)
    return result


def symmetric(matrix):
    return (matrix + matrix.T) / 2


class SpinModel:
    def __init__(self, n, seed):
        self.n, self.d = n, 2**n
        self.labels = list(itertools.product(range(4), repeat=n))
        self.ops = [tensor(PAULI[axis] for axis in label) for label in self.labels]
        self.basis = np.column_stack([p.reshape(-1, order='F') for p in self.ops]) / np.sqrt(self.d)
        self.index = {label: i for i, label in enumerate(self.labels)}
        rng = np.random.default_rng(seed)
        xops = [self.operator(1, [i]) for i in range(n)]
        zops = [self.operator(3, [i]) for i in range(n)]
        self.xsum = sum(xops)
        self.couplings = [rng.uniform(-1, 1) for _ in itertools.combinations(range(n), 2)]
        interaction = sum(j*self.operator(1, pair) for j, pair in zip(self.couplings, itertools.combinations(range(n), 2)))
        H = interaction + 0.5*sum(zops) + 0.75*self.xsum
        signs = (1,-1,-1) if n==3 else (1,1,-1,-1)
        lowering = np.array([[0,1],[0,0]])
        jump = sum(sign*tensor(lowering if k==i else PAULI[0] for k in range(n)) for i,sign in enumerate(signs))
        eye = np.eye(self.d)
        K = jump.conj().T @ jump
        dissipator = np.kron(jump.conj(), jump) - (np.kron(eye,K) + np.kron(K.T,eye))/2
        def commutator(h): return -1j*(np.kron(eye,h) - np.kron(h.T,eye))
        self.static = self.ptm(commutator(H))
        self.drive = self.ptm(commutator(0.25*self.xsum))
        self.loss = self.ptm(dissipator)
        self.groups = []
        for axis in (1,2,3):
            group = [j for j,word in enumerate(self.labels) if set(word)<= {0,axis} and sum(a!=0 for a in word) in (1,2)]
            self.groups.append(group)
        self.features = np.concatenate(self.groups)

    def ptm(self, generator):
        value = self.basis.conj().T @ generator @ self.basis
        if np.max(np.abs(value.imag)) > 2e-12:
            raise ValueError('Expected a real generator in Hermitian coordinates')
        return value.real

    def operator(self, axis, sites):
        label = tuple(axis if i in sites else 0 for i in range(self.n))
        return self.ops[self.index[label]]

    def maps(self, rate, gain):
        trace_errors, choi_minima, affines = [], [], []
        for u in (-1.,1.):
            E = la.expm(0.5*(self.static+rate*self.loss+u*gain*self.drive))
            trace_errors.append(la.norm(E[0]-np.eye(1, len(E))[0],ord=np.inf))
            S = self.basis @ E @ self.basis.conj().T
            choi = S.reshape((self.d,)*4, order='F').transpose(0,2,1,3).reshape(self.d**2,self.d**2)
            choi_minima.append(la.eigvalsh((choi+choi.conj().T)/2,subset_by_index=[0,0])[0])
            affines.append((E[1:,1:], E[1:,0]))
        return affines, max(trace_errors), min(choi_minima)

    def noise(self, mean, covariance):
        all_mean = np.r_[1., mean]
        noise = np.zeros((len(self.features),len(self.features)))
        offset = 0
        for group in self.groups:
            block = np.empty((len(group),len(group)))
            for i,j in enumerate(group):
                for k,l in enumerate(group):
                    product = tuple(a if b==0 else b if a==0 else 0 for a,b in zip(self.labels[j],self.labels[l]))
                    block[i,k] = all_mean[self.index[product]] - mean[j-1]*mean[l-1] - covariance[j-1,l-1]
            noise[offset:offset+len(group),offset:offset+len(group)] = block
            offset += len(group)
        return symmetric(noise)


class SteinSolver:
    """Cached Schur solution of X-A X A^T=C using a bilinear transform."""
    def __init__(self, A):
        eye = np.eye(len(A))
        self.inverse = la.solve(A+eye, eye)
        cayley = (A-eye) @ self.inverse
        self.tri, self.orth = la.schur(cayley,output='real')
        self.rhs_left = self.orth.T @ self.inverse
        self.trsyl = la.get_lapack_funcs('trsyl',(self.tri,))

    def solve(self, C):
        rhs = -2*self.rhs_left @ C @ self.rhs_left.T
        x, scale, info = self.trsyl(self.tri,self.tri,rhs,trana='N',tranb='T')
        if info != 0: raise ArithmeticError(f'Stein solver failed ({info})')
        return symmetric(self.orth @ (x/scale) @ self.orth.T)


def solve_full(C, A, D, stein):
    shape = A.shape
    def residual(vec):
        x = vec.reshape(shape)
        return (x - A@x@A.T - D@x@D.T).ravel()
    operator = LinearOperator((A.size,A.size), matvec=residual, dtype=float)
    precondition = LinearOperator(operator.shape,matvec=lambda z: stein.solve(z.reshape(shape)).ravel(),dtype=float)
    sol, info = gmres(operator,C.ravel(),M=precondition,rtol=4e-11,atol=0.,restart=70,maxiter=100)
    if info != 0: raise ArithmeticError(f'Moment solver failed ({info})')
    sol = symmetric(sol.reshape(shape))
    error = la.norm(residual(sol.ravel())-C.ravel()) / la.norm(C)
    return sol,error


def horizon(A, gramian, score):
    threshold = score(gramian)*0.1
    def tail(t):
        power = np.linalg.matrix_power(A,t)
        return score(power @ gramian @ power.T)
    lo,hi = 0,1
    while tail(hi)>threshold: hi *= 2
    while hi-lo>1:
        mid = (lo+hi)//2
        if tail(mid)>threshold: lo=mid
        else: hi=mid
    return hi


def compute(model,rate,gain):
    maps,trace_error,choi_min = model.maps(rate,gain)
    (Aminus,bminus),(Aplus,bplus) = maps
    A, D = (Aplus+Aminus)/2,(Aplus-Aminus)/2
    mean = la.solve(np.eye(len(A))-A,(bplus+bminus)/2)
    v = D@mean + (bplus-bminus)/2
    V = np.outer(v,v)
    stein = SteinSolver(A)
    sigma,sigma_res = solve_full(V,A,D,stein)
    Q,Q_res = solve_full(V+D@sigma@D.T,A,D,stein)
    features=model.features-1
    ix = np.ix_(features,features)
    observed = sigma[ix] + model.noise(mean,sigma)/SHOTS
    # All finite-shot observed covariances here are positive definite.
    inverse = la.solve(observed,np.eye(len(observed)),assume_a='pos')
    def score(x): return float(np.sum(inverse*x[ix]))
    order = stein.solve(V)
    W = A @ order @ A.T
    complete = score(sigma)
    grade_scores = [score(order)]
    for _ in range(5):
        order = stein.solve(D @ order @ D.T)
        grade_scores.append(score(order))
    density = (sum(m*op for m,op in zip(np.r_[1.,mean],model.ops)))/model.d
    return {'Rpast':score(W),'horizon90':horizon(A,W,score),'mean_order':score(Q)/complete,
            'fraction_le6':sum(grade_scores)/complete,'capacity':complete,'observed_variance':float(np.trace(sigma[ix])),
            'covariance_residual':sigma_res,'order_residual':Q_res,'tp_error':trace_error,
            'min_choi':choi_min,'min_steady_state':la.eigvalsh(density)[0]}


def run(n,limit=None):
    records=[]
    seeds = SEEDS if n==3 else (20261101,)
    rates = RATES if n==3 else (64,256,1024)
    for seed in seeds:
        model = SpinModel(n,seed)
        for rate in rates:
            gains = [('fixed',1.),('matched',8/np.sqrt(rate))]
            if n==3: gains.append(('faster',64/rate))
            reused={}
            for law,gain in gains:
                if gain not in reused: reused[gain]=compute(model,rate,gain)
                records.append({'n':n,'seed':seed,'gamma':rate,'law':law,'eta':gain,**reused[gain]})
                if limit and len(records)>=limit:return records
        print(f'finished N={n} seed={seed}',flush=True)
    return records


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--n',type=int,choices=(3,4),default=3)
    ap.add_argument('--limit',type=int,default=None,help='For a short smoke check only; override output path')
    ap.add_argument('--output',type=Path)
    args=ap.parse_args()
    if args.limit and not args.output: ap.error('specify --output when running a partial grid')
    rows=run(args.n,args.limit)
    output=args.output or HERE/f'spin_n{args.n}_population.csv'
    with output.open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
